<!--Jasmin Rutter, 2/17/23, IT 202-010, Unit 3 Fruit Stand, jnr7@njit.edu -->
<?php 
require('databaseF.php');

// acquire ID of fruit category
$category_id = filter_input(INPUT_GET, 'category_id',
                            FILTER_VALIDATE_INT);
if ($category_id == NULL || $category_id == FALSE) {
    $category_id = 1;
}

// acquire name of fruit category 
$fruit_name = filter_input(INPUT_GET, 'fruit_name');
if ($fruit_name == NULL || $fruit_name == FALSE) {
    $fruit_name = 1;
}
 
// acquire name for selected category
$queryCategory = 'SELECT fruitCategoryName
                  FROM fruitcategories
                  WHERE fruitCategoryID = :category_id';
$statement1 = $db->prepare($queryCategory);
$statement1->bindValue(':category_id', $category_id);
$statement1->execute();
$fruitcategories = $statement1->fetch();
$fruit_categories_name = $fruitcategories['fruitCategoryName'];
$statement1->closeCursor();

// acquire all categories
$queryAllCategories = 'SELECT * FROM fruitcategories
                      ORDER BY fruitCategoryID';
$statement2 = $db->prepare($queryAllCategories);
$statement2->execute();
$categoryName = $statement2->fetchAll();
$statement2->closeCursor();
 
// acquire products for category that's selected
$queryProducts = 'SELECT * FROM fruit
                  ORDER BY fruitID';
$statement3 = $db->prepare($queryProducts);
$statement3->execute();
$products = $statement3->fetchAll();
$statement3->closeCursor();


 
?>

<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="stylesF.css"/>
    <title>Fruit Burst</title>
    <link rel="shortcut icon" href="images/icon.jpg"/>

</head>
    <body>
        <main>
            <center>
            <?php include('header.php'); ?>

            <h1>Fruit List</h1>
            
            <section>
                <table>
                    <tr>
                        <th>Fruit Category</th>
                        <th>Code</th>
                        <th>Name</th>
                        <th>Description</th>
                        <th class="right">Price</th>
                    </tr>
                    

                    <?php foreach ($products as $product) : ?>
                    <tr>
                        <td><?php echo $product['fruitCategoryID']; ?></td>
                        <td><?php echo $product['fruitCode']; ?></td>
                        <td><?php echo $product['fruitName']; ?></td>
                        <td><?php echo $product['description']; ?></td>
                        <td class="right">$<?php echo $product['price']; ?>
                        
                    </tr>
                    <?php endforeach; ?>
                </table>
            </section>

            <?php include('footer.php'); ?>

            </center>

        </main>
    </body>
</html>
