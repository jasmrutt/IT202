<!--Jasmin Rutter, 2/17/23, IT 202-010, Unit 3 Fruit Stand, jnr7@njit.edu -->

<html>
    <head>
    </head>
    <body>
        <img id="logo" src="images/Logo.png" alt="logo" width=125px height=125px>
        <nav>
            <a href="home.php">Home</a> |
            <a href="shipping_format.php">Shipping</a> |
            <a href="fruits_list.php">Fruit</a>
        </nav>
    </body>
</html>