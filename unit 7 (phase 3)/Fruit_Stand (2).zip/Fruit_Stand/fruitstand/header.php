<!--Jasmin Rutter, 2/17/23, IT 202-010, Unit 3 Fruit Stand, jnr7@njit.edu -->

<html>
    <head>
        <link rel="stylesheet" href="stylesF.css">
    </head>
    <body>
        <img id="logo" src="images/Logo.png" alt="logo" width=125px height=125px>
        <nav>
            <ul>
                <li><a href="home.php">Home</a></li>
                <li><a href="shipping_format.php">Shipping</a></li>
                <li><a href="fruits_list.php">Fruit</a></li>
                <li><a href="add_fruit_form.php">Create</a></li>
            <ul>
        </nav>
    </body>
</html>