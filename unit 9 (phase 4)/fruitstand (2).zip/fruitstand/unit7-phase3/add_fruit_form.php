<!--Jasmin Rutter, 3/23/23, IT 202-010, Unit 7 Fruit Stand, jnr7@njit.edu -->
<?php
    require_once('../unit5-phase2/databaseF.php');

    //query for categories
    $query = 'SELECT * FROM fruitcategories ORDER BY fruitCategoryID';

    $statement = $db->prepare($query);
    $statement->execute();
    $categories = $statement->fetchAll();
    $statement->closeCursor();
    // Start the session
session_start();
    // Check if the user is logged in
if (!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true) {
    // If the user is not logged in, redirect them to the login page
    header("Location: ../unit9-phase4/loginF.php");
    exit();
  }
?>

<html>
    <head>
        <link rel="stylesheet" href="../unit3-phase1/stylesF.css"/>
        <title>Fruit Burst</title>
        <link rel="shortcut icon" href="../unit3-phase1/images/icon.jpg"/>
    </head>
    <main>
        <body>
        
            <center>
            <?php include('../unit3-phase1/header.php'); ?>
                <h1>Add Product</h1>
            </center>
                <form action="add_fruit.php" method="post">
                    <label>Category:</label>
                    <select name="fruit_category_id">
                        <?php foreach ($categories as $category) : ?>
                             <option value="<?php
                                echo $category['fruitCategoryID']; ?>">
                                <?php echo $category['fruitCategoryName']; ?>
                            </option>
                        <?php endforeach; ?>
                    </select><br><br>
                    <label>Fruit Code:</label>
                    <input type="text" name="fruit_code"><br><br>
                    <label>Fruit Name:</label>
                    <input type="text" name="fruit_name"><br><br>
                    <label>Description:</label>
                    <input type="text" name="description"><br><br>
                    <label>Price:</label>
                    <input type="text" name="price"><br><br>
                    <input type="submit" name="Submit">
                    <input type="reset"><br>
                </form>

            <center>
                <?php include('../unit3-phase1/footer.php'); ?>
            </center>

        </body>
    </main>
    
</html>
