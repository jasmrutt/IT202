<!--Jasmin Rutter, 2/17/23, IT 202-010, Unit 3 Fruit Stand, jnr7@njit.edu -->

<?php
    session_start();
    //slide 23
    $_SESSION = []; // clear all session data
    session_destroy(); // cleans up session id
    $login_message = 'You have been logged out.';
?>