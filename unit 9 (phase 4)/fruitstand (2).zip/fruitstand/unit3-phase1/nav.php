<nav>
        <ul>
            <li><a href="../unit3-phase1/home.php">Home</a></li>
            <li><a href="../unit3-phase1/shipping_format.php">Shipping</a></li>
            <li><a href="../unit5-phase2/fruits_list.php">Fruit</a></li>
            <li><a href="../unit7-phase3/add_fruit_form.php">Create</a></li>
            <li><a href="../unit9-phase4/add_user_form.php">Add User</a></li>

            
            <?php 

            if ($_SESSION == true) {?>
                <li><a href="../unit9-phase4/logoutF.php"></li>
            <?php    
            }
            ?>
            
        <ul>
    </nav>