<!--Jasmin Rutter, 2/17/23, IT 202-010, Unit 3 Fruit Stand, jnr7@njit.edu -->

<?php
    session_start();
    echo "<pre>";
    print_r($_SESSION);
    echo "</pre>";
?>

