<!--Jasmin Rutter, 2/17/23, IT 202-010, Unit 3 Fruit Stand, jnr7@njit.edu -->
<html>
    <head>
        <link rel="stylesheet" href="stylesF.css">
        <title>Fruit Burst</title> 
        <link rel="shortcut icon" href="images/icon.jpg">
    </head>
    <body>
        <main>
            <h1>Database Error</h1>
            <p>There was an error connecting to database</p>
            <p> error Message: <?php echo $error_message; ?></p>
        </main>
    </body>
</html>