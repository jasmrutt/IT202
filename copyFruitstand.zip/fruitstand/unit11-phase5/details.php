<!--Jasmin Rutter, 2/17/23, IT 202-010, Unit 3 Fruit Stand, jnr7@njit.edu -->
<?php 
require('../unit5-phase2/databaseF.php');
global $exists;
$fruit_id = $_GET['fruit_id'];
if ($fruit_id == NULL || $fruit_id == FALSE) {
    $exists = 1;
}

// Construct the SQL query
$queryProduct = "SELECT * FROM fruit WHERE fruitID = $fruit_id";

// Execute the query and fetch the result set
$statement = $db->prepare($queryProduct);
$statement->execute();
$products = $statement->fetchAll();
$statement->closeCursor();


// construct the image filename
$image_filename = $fruit_id . "-bw.jpg";

?>
<!DOCTYPE html>
<html>
<html>
    <center>
    <head>
        <link rel="stylesheet" href="stylesF.css">
        <title>Fruit Burst</title> 
        <link rel="shortcut icon" href="images/icon.jpg">
    </head>
    <body>
        <h1>Fruit List</h1>
        <?php include('../unit3-phase1/header.php'); ?>

        <main>
            <section>
                <?php
                if($exists > 0){
                    echo "Fruit does not exist";
                }else{
                    '<table>
                        <tr>
                    

    
                            <td><?php echo $product['fruitCategoryID']; ?></td>
                            <td><a href="../unit11-phase5/details.php?fruit_id=<?php
                                    echo $product['fruitID']; ?>">
                                <?php echo $product['fruitCode']; ?></a></td>
                            <td><?php echo $product['fruitName']; ?></td>
                            <td><?php echo $product['description']; ?></td>
                            <td class="right">$<?php echo $product['price']; ?>
                            </td>
            
                        </tr>
                    </table>'

                    echo '<img src="../unit3-phase1/images/$image_filename alt="fruit">';
                }?>
                    
                </center>
            </section>
        </main>
        <script
            src="https://code.jquery.com/jquery-3.6.4.slim.min.js"
            integrity="sha256-a2yjHM4jnF9f54xUQakjZGaqYs/V1CYvWpoqZzC2/Bw="
             crossorigin="anonymous">
        </script>
        <script src="rollover.js"></script>    
<?php include('../unit3-phase1/footer.php'); ?>
</body>
</html>