<!--Jasmin Rutter, 2/17/23, IT 202-010, Unit 3 Fruit Stand, jnr7@njit.edu -->

<?php

?>
<html>
    <head>

    </head>
    <body>
        <h5>
            <p>Jasmin Rutter, 2/17/23, Internet Applications Section 010, Unit 3 Fruit Stand -  
        <a href = "mailto: jnr7@njit.edu"> jnr7@njit.edu </a> </p>
        </h5>
    </body>
</html>